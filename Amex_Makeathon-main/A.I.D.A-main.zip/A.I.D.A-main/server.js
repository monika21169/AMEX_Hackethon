const { GoogleGenerativeAI } = require("@google/generative-ai");
const cors = require('cors'); 
const express = require('express');
const fetch = require('node-fetch'); // For version 2

const app = express();
const port = 3000; 


const generativeAI = new GoogleGenerativeAI({ apiKey: "AIzaSyAriUVgKMXKco8HF96kU-cuncazBQMdIwg" });

app.use(cors()); 
app.use(express.json()); 

app.post('/chat', async (req, res) => {
  try {
    const userMessage = req.body.message;
    const model = generativeAI.getGenerativeModel({ model: "gemini-pro" }); 

    const fetchResponse = await fetch('https://generativelanguage.googleapis.com/v1beta/models/gemini-pro:generateContent?key=AIzaSyAriUVgKMXKco8HF96kU-cuncazBQMdIwg', {
      method: 'POST',
      headers: {
       'Content-Type': 'application/json' 
      },
      body: JSON.stringify({
        contents: [{ parts: [{ text: userMessage }] }]
      })
    });

    // Check if request was successful
    if (!fetchResponse.ok) {
      throw new Error(`Gemini API request failed with status ${fetchResponse.status}`);
    }

    const geminiResponse = await fetchResponse.json(); // Parse JSON response
    const botResponse = geminiResponse.candidates[0].content.parts[0].text; 

    res.json({ botResponse }); 
  } catch (error) {
    console.error("Error communicating with Gemini:", error);
    res.status(500).json({ error: "Something went wrong on the server." });
  }
});

app.listen(port, () => {
  console.log(`A.I.D.A. server listening on port ${port}`);
});
