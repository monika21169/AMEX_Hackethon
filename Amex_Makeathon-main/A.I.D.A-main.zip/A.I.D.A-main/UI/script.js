document.getElementById('sendButton').addEventListener('click', function() {
    const message = document.getElementById('messageInput').value;
    document.getElementById('messageInput').value = ''; // Clear the input field 

    fetch('http://localhost:3000/chat', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json'
        },
        body: JSON.stringify({ message })
    })
    .then(response => response.json())
    .then(data => {
        const chatBody = document.querySelector('.chat-body');

        // User Message
        const userMessageDiv = document.createElement('div');
        userMessageDiv.classList.add('user-message'); 
        userMessageDiv.textContent = "You: " + message; 
        chatBody.appendChild(userMessageDiv);

        // Bot Response
        const botMessageDiv = document.createElement('div');
        botMessageDiv.classList.add('bot-message');  

        // Updated formatting logic
        let formattedResponse = data.botResponse;

        // Bold Text (double stars)
        formattedResponse = formattedResponse.replace(/\*\*([^\*]+)\*\*/g, '<strong>$1</strong>');

        // Bullet Points (single star)
        formattedResponse = formattedResponse.replace(/\* (.*)/g, '<li>$1</li>'); 

        // Wrap in <ul> if bullet points are present
        if (formattedResponse.includes('<li>')) {
            formattedResponse = '<ul>' + formattedResponse + '</ul>';
        }

        botMessageDiv.innerHTML = "A.I.D.A: " + formattedResponse; 
        chatBody.appendChild(botMessageDiv);  
    })
    .catch((error) => {
        console.error('Error:', error); 
        // Add a user-friendly error message on the frontend
        const chatBody = document.querySelector('.chat-body');
        const errorMessageDiv = document.createElement('div');
        errorMessageDiv.textContent = "Error: Couldn't connect to the chatbot. Please try again.";
        chatBody.appendChild(errorMessageDiv);
    });
});
